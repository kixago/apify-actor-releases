# Pandoc Document Converter

Universal document format converter powered by Pandoc. Convert between Markdown, HTML, EPUB, DOCX, LaTeX, and many other formats.

## Features

- **20+ Format Support**: Convert between Markdown, HTML, EPUB, DOCX, LaTeX, reStructuredText, AsciiDoc, MediaWiki, and more
- **Standalone Documents**: Generate complete HTML/LaTeX documents with headers
- **Custom Templates**: Use your own pandoc templates for branded output
- **Fast & Reliable**: Built in Rust for maximum performance
- **No File Handling**: Direct content conversion without filesystem overhead

## Use Cases

- Convert documentation from Markdown to HTML
- Transform blog posts between formats
- Generate EPUB ebooks from Markdown
- Export Markdown to Word documents
- Convert between different markup languages
- Batch process documentation

## Input

```json
{
  "content": "# My Document\n\nThis is **bold** text.",
  "fromFormat": "markdown",
  "toFormat": "html",
  "standalone": true
}
```

### Input Fields

| Field        | Type    | Required | Description                                                |
| ------------ | ------- | -------- | ---------------------------------------------------------- |
| `content`    | string  | Yes      | The document content to convert                            |
| `fromFormat` | string  | Yes      | Source format (see supported formats below)                |
| `toFormat`   | string  | Yes      | Target format (see supported formats below)                |
| `standalone` | boolean | No       | Generate standalone document with headers (default: false) |
| `template`   | string  | No       | Custom pandoc template path                                |

### Supported Formats

- `markdown` - Standard Markdown
- `html` - HTML
- `epub` - EPUB ebook format
- `docx` - Microsoft Word
- `latex` - LaTeX
- `rst` - reStructuredText
- `asciidoc` - AsciiDoc
- `mediawiki` - MediaWiki markup
- `org` - Emacs Org Mode
- `commonmark` - CommonMark strict Markdown
- `gfm` - GitHub Flavored Markdown

## Output

```json
{
  "convertedContent": "<h1>My Document</h1>\n<p>This is <strong>bold</strong> text.</p>",
  "fromFormat": "markdown",
  "toFormat": "html",
  "inputSize": 37,
  "outputSize": 67,
  "success": true
}
```

### Output Fields

| Field              | Type    | Description                         |
| ------------------ | ------- | ----------------------------------- |
| `convertedContent` | string  | The converted document              |
| `fromFormat`       | string  | Source format used                  |
| `toFormat`         | string  | Target format produced              |
| `inputSize`        | number  | Size of input in bytes              |
| `outputSize`       | number  | Size of output in bytes             |
| `success`          | boolean | Whether conversion succeeded        |
| `warnings`         | string  | Error messages if conversion failed |

## Examples

### Markdown to HTML

```json
{
  "content": "# Title\n\nParagraph with **bold** and *italic*.",
  "fromFormat": "markdown",
  "toFormat": "html",
  "standalone": false
}
```

### HTML to Markdown

```json
{
  "content": "<h1>Title</h1><p>Paragraph with <strong>bold</strong>.</p>",
  "fromFormat": "html",
  "toFormat": "markdown"
}
```

### Markdown to EPUB

```json
{
  "content": "# My Book\n\n## Chapter 1\n\nContent here...",
  "fromFormat": "markdown",
  "toFormat": "epub",
  "standalone": true
}
```

### GitHub Markdown to HTML

````json
{
  "content": "# Repo\n\n```python\nprint('hello')\n```\n\n- [ ] Task",
  "fromFormat": "gfm",
  "toFormat": "html",
  "standalone": true
}
````

## Performance

- **Conversion Speed**: 10-50ms for typical documents
- **Throughput**: 1000+ conversions per minute
- **Memory**: Low memory footprint, no temp files

## Error Handling

If conversion fails, the Actor returns:

```json
{
  "convertedContent": "",
  "success": false,
  "warnings": "Pandoc conversion failed: unsupported format"
}
```

Common errors:

- Unsupported format specified
- Invalid document structure
- Malformed input content

## Pricing

This Actor uses compute resources based on document size:

- Small docs (<10KB): ~0.001 credits
- Medium docs (10-100KB): ~0.01 credits
- Large docs (>100KB): ~0.1 credits

## Support

For issues or feature requests, please contact the developer.

## Technical Details

- **Language**: Rust
- **Pandoc Version**: Latest stable
- **Runtime**: Apify SDK for Rust


